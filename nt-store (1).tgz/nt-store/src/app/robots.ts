import type { MetadataRoute } from 'next';
import { SITE_URL } from '@/lib/data';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/api', '/checkout', '/carrinho', '/pedido'] }],
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
